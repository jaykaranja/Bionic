from django.apps import AppConfig


class MediaapiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mediaapi'
