from enum import Enum

class Lookups(Enum):
    Genres = 1
    Albums = 2
    Artists = 3
